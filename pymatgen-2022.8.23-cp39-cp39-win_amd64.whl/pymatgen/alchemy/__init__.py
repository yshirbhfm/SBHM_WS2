# Copyright (c) Pymatgen Development Team.
# Distributed under the terms of the MIT License.

"""
This package provides the modules for performing large scale transformations on
a large number of structures.
"""
