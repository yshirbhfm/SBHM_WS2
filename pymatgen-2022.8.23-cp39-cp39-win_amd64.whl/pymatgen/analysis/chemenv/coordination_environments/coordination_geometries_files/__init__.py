"""
Coordination geometry files.
"""
