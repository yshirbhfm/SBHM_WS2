"""
Package for analyzing connectivity.
"""
